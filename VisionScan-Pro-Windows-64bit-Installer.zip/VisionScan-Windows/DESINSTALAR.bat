@echo off
title Vision-Scan Pro - Desinstalador
color 0C

echo.
echo ========================================
echo   VISION-SCAN PRO - DESINSTALADOR
echo ========================================
echo.
echo ATENCAO: Este processo ira remover completamente
echo o Vision-Scan Pro do seu computador.
echo.
echo Tem certeza que deseja continuar?
echo.
echo Pressione qualquer tecla para DESINSTALAR
echo ou feche esta janela para CANCELAR
echo.
pause >nul

echo.
echo [INFO] Iniciando desinstalacao...
timeout /t 2 >nul

set "INSTALL_DIR=%ProgramFiles%\VisionScan-Pro"
set "DESKTOP=%USERPROFILE%\Desktop"
set "STARTMENU=%APPDATA%\Microsoft\Windows\Start Menu\Programs"

echo [INFO] Removendo atalhos...
if exist "%DESKTOP%\Vision-Scan Pro.url" del "%DESKTOP%\Vision-Scan Pro.url" >nul 2>&1
if exist "%STARTMENU%\Vision-Scan Pro" rmdir /S /Q "%STARTMENU%\Vision-Scan Pro" >nul 2>&1

echo [INFO] Removendo arquivos do programa...
if exist "%INSTALL_DIR%" rmdir /S /Q "%INSTALL_DIR%" >nul 2>&1

echo [INFO] Removendo entradas do registro...
reg delete "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\VisionScanPro" /f >nul 2>&1

echo.
echo ========================================
echo   DESINSTALACAO CONCLUIDA COM SUCESSO!
echo ========================================
echo.
echo O Vision-Scan Pro foi completamente removido
echo do seu computador.
echo.
echo Obrigado por usar o Vision-Scan Pro!
echo.
echo Desenvolvido por Iris Clin
echo.
echo Pressione qualquer tecla para finalizar...
pause >nul

exit /b 0

