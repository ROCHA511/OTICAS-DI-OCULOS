# VISION-SCAN PRO - INSTALADOR WINDOWS 64-BIT

## 📱 SOBRE O VISION-SCAN PRO

O Vision-Scan Pro é um revolucionário aplicativo de pupilometria digital que transforma seu smartphone em um equipamento óptico profissional.

### 🏆 DESENVOLVIDO POR:
- **Empresa:** Íris Clin (CNPJ: 11.901.886/0001-60)
- **Proprietários:** 
  - Dioenne Conceição Rocha (CPF: 810.939.965-15)
  - Marly Lima Rocha (CPF: 837.597.115-91)
  - Mariana Lima Rocha (CPF: 863.634.275-92)

### ⚡ FUNCIONALIDADES PRINCIPAIS:
- ✅ Medição de DNP (Distância Nazo-Pupilar)
- ✅ Distância Pupilar (DP)
- ✅ Centro Óptico
- ✅ Altura Vertical
- ✅ Diagonal Maior
- ✅ Ponte e Aro
- ✅ Reflexo Pupilar com Flash
- ✅ Sistema Financeiro Completo
- ✅ Gestão de Vendedores e Comissões
- ✅ Controle de Notas e Crediário
- ✅ Relatórios Comparativos

## 🚀 INSTALAÇÃO

### REQUISITOS DO SISTEMA:
- Windows 10/11 (64-bit)
- Navegador moderno (Chrome, Edge, Firefox)
- Câmera integrada ou externa
- 100MB de espaço livre

### PASSOS PARA INSTALAÇÃO:

1. **EXTRAIR ARQUIVOS**
   - Extraia todos os arquivos para uma pasta
   - Mantenha a estrutura de pastas

2. **EXECUTAR INSTALADOR**
   - Clique com botão direito em "INSTALAR.bat"
   - Selecione "Executar como administrador"
   - Siga as instruções na tela

3. **INICIAR APLICATIVO**
   - Use o atalho criado na área de trabalho
   - Ou acesse pelo Menu Iniciar > Vision-Scan Pro

## 📋 MÓDULOS INCLUÍDOS:

### 1. PÁGINA PRINCIPAL (index.html)
- Interface principal do aplicativo
- Acesso a todas as funcionalidades

### 2. TESTES MÚLTIPLOS (testes-multiplos.html)
- Realizar múltiplos testes consecutivos
- Histórico de medições
- Contador de testes

### 3. REFLEXO PUPILAR (reflexo-pupilar.html)
- Medições baseadas no reflexo da pupila
- Maior precisão profissional
- Flash automático

### 4. SISTEMA FINANCEIRO (sistema-financeiro.html)
- Dashboard completo
- Gestão de notas e crediário
- Comissões de vendedores (2%)
- Comparações mensais

### 5. RESULTADOS COMPLETOS (resultados-completos.html)
- Relatórios detalhados
- Recomendações personalizadas
- Exportação em PDF

## 🔧 CONFIGURAÇÃO

### PRIMEIRA EXECUÇÃO:
1. Abra o Vision-Scan Pro
2. Permita acesso à câmera quando solicitado
3. Calibre a distância (1 metro recomendado)
4. Realize um teste para verificar funcionamento

### DICAS DE USO:
- Use em ambiente bem iluminado
- Mantenha distância de 1 metro
- Olhe diretamente para a câmera
- Aguarde o flash para melhor precisão

## 📊 SISTEMA FINANCEIRO

### FUNCIONALIDADES:
- **Dashboard:** Visão geral das vendas
- **Notas:** Controle de crediário e parcelas
- **Vendedores:** Gestão de comissões (2%)
- **Caixa:** Fluxo de entrada e saída

### COMO USAR:
1. Cadastre vendedores no sistema
2. Registre vendas (à vista ou prazo)
3. Controle vencimentos de notas
4. Baixe pagamentos automaticamente
5. Acompanhe comissões em tempo real

## 🛡️ SEGURANÇA E PRIVACIDADE

- Todos os dados ficam armazenados localmente
- Não há envio de informações para servidores externos
- Imagens capturadas são processadas no dispositivo
- Conformidade com LGPD

## 📞 SUPORTE TÉCNICO

### CONTATO:
- **Empresa:** Íris Clin
- **Endereço:** R 23 DE ABRIL, 37 - CENTRO - ITUBERA/BA
- **Telefone:** (73) 3256-1599
- **Email:** convicta.contabil@hotmail.com

### PROBLEMAS COMUNS:

**Câmera não funciona:**
- Verifique permissões do navegador
- Teste em navegador diferente
- Reinicie o aplicativo

**Flash não ativa:**
- Verifique se o dispositivo tem flash
- Teste em ambiente escuro
- Use modo visual se necessário

**Medições imprecisas:**
- Mantenha distância de 1 metro
- Use boa iluminação
- Olhe diretamente para câmera

## 📄 LICENÇA E DIREITOS

### PROPRIEDADE INTELECTUAL:
- Software protegido por direitos autorais
- Uso restrito conforme licença
- Proibida reprodução sem autorização

### TERMOS DE USO:
- Uso profissional em óticas
- Não redistribuir sem permissão
- Respeitar direitos dos proprietários

## 🔄 ATUALIZAÇÕES

### VERSÃO ATUAL: 1.0.0 Beta

### PRÓXIMAS FUNCIONALIDADES:
- Integração com sistemas de gestão
- Relatórios avançados
- Backup em nuvem
- App mobile nativo

## ⚠️ IMPORTANTE

Este é um software em versão BETA para testes.
Para uso comercial, entre em contato com os proprietários.

---

**© 2025 Íris Clin - Todos os direitos reservados**
**Desenvolvido com tecnologia Vision-Scan Pro**

