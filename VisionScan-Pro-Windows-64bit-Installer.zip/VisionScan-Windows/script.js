// Vision-Scan - JavaScript Funcional
class VisionScan {
    constructor() {
        this.currentDemo = 'measurement';
        this.isScanning = false;
        this.measurements = {
            dnp: 0,
            height: 0,
            angle: 0,
            pupilDiameter: 0
        };
        this.clients = [];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadDemoContent();
        this.startAnimations();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                this.scrollToSection(link.getAttribute('href'));
                this.setActiveNavLink(link);
            });
        });

        // Demo buttons
        document.querySelectorAll('.demo-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const demo = btn.getAttribute('onclick').match(/'([^']+)'/)[1];
                this.showDemo(demo);
            });
        });

        // Pricing buttons
        document.querySelectorAll('.pricing-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.handlePricingClick(btn);
            });
        });

        // Contact form
        const contactForm = document.querySelector('.contact-form form');
        if (contactForm) {
            contactForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleContactSubmit(e);
            });
        }

        // Login form
        const loginForm = document.querySelector('.login-form form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin(e);
            });
        }

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }

    scrollToSection(href) {
        const target = document.querySelector(href);
        if (target) {
            const headerHeight = document.querySelector('.header').offsetHeight;
            const targetPosition = target.offsetTop - headerHeight;
            
            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    }

    setActiveNavLink(activeLink) {
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        activeLink.classList.add('active');
    }

    showDemo(demoType) {
        this.currentDemo = demoType;
        
        // Update active button
        document.querySelectorAll('.demo-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        event.target.closest('.demo-btn').classList.add('active');

        // Load demo content
        this.loadDemoContent();
    }

    loadDemoContent() {
        const demoApp = document.getElementById('demoApp');
        if (!demoApp) return;

        const demos = {
            measurement: this.createMeasurementDemo(),
            analysis: this.createAnalysisDemo(),
            comparison: this.createComparisonDemo(),
            report: this.createReportDemo()
        };

        demoApp.innerHTML = demos[this.currentDemo] || demos.measurement;
        this.initDemoInteractions();
    }

    createMeasurementDemo() {
        return `
            <div class="demo-header">
                <div class="demo-title">
                    <i class="fas fa-ruler"></i>
                    <span>Medição DNP</span>
                </div>
                <div class="demo-status">Pronto para escanear</div>
            </div>
            
            <div class="demo-camera">
                <div class="camera-view">
                    <div class="face-outline">
                        <div class="eye left-eye">
                            <div class="pupil"></div>
                        </div>
                        <div class="eye right-eye">
                            <div class="pupil"></div>
                        </div>
                        <div class="measurement-line">
                            <span class="measurement-value">64.5mm</span>
                        </div>
                    </div>
                    <div class="scan-overlay">
                        <div class="scan-grid"></div>
                    </div>
                </div>
            </div>
            
            <div class="demo-controls">
                <button class="scan-btn" onclick="visionScan.startScan()">
                    <i class="fas fa-camera"></i>
                    Iniciar Medição
                </button>
            </div>
            
            <div class="demo-results">
                <div class="result-item">
                    <span class="label">DNP:</span>
                    <span class="value" id="dnpValue">64.5mm</span>
                </div>
                <div class="result-item">
                    <span class="label">Altura:</span>
                    <span class="value" id="heightValue">28.2mm</span>
                </div>
                <div class="result-item">
                    <span class="label">Precisão:</span>
                    <span class="value success">99.5%</span>
                </div>
            </div>
        `;
    }

    createAnalysisDemo() {
        return `
            <div class="demo-header">
                <div class="demo-title">
                    <i class="fas fa-brain"></i>
                    <span>Análise Facial IA</span>
                </div>
                <div class="demo-status">Analisando...</div>
            </div>
            
            <div class="demo-camera">
                <div class="camera-view">
                    <div class="face-analysis">
                        <div class="face-mesh">
                            <div class="mesh-point" style="top: 20%; left: 30%;"></div>
                            <div class="mesh-point" style="top: 20%; right: 30%;"></div>
                            <div class="mesh-point" style="top: 40%; left: 50%;"></div>
                            <div class="mesh-point" style="bottom: 40%; left: 50%;"></div>
                            <div class="mesh-point" style="bottom: 20%; left: 50%;"></div>
                        </div>
                        <div class="face-outline-analysis"></div>
                    </div>
                </div>
            </div>
            
            <div class="demo-results">
                <div class="analysis-result">
                    <div class="result-category">
                        <span class="category-label">Tipo de Rosto:</span>
                        <span class="category-value">Oval</span>
                    </div>
                    <div class="result-category">
                        <span class="category-label">Proporção:</span>
                        <span class="category-value">Áurea</span>
                    </div>
                    <div class="result-category">
                        <span class="category-label">Simetria:</span>
                        <span class="category-value">95%</span>
                    </div>
                </div>
                
                <div class="recommendations">
                    <h4>Recomendações:</h4>
                    <div class="rec-item">✓ Armações retangulares</div>
                    <div class="rec-item">✓ Lentes progressivas</div>
                    <div class="rec-item">✓ Anti-reflexo premium</div>
                </div>
            </div>
        `;
    }

    createComparisonDemo() {
        return `
            <div class="demo-header">
                <div class="demo-title">
                    <i class="fas fa-glasses"></i>
                    <span>Comparação de Lentes</span>
                </div>
                <div class="demo-status">Demonstração interativa</div>
            </div>
            
            <div class="comparison-container">
                <div class="comparison-tabs">
                    <button class="comp-tab active" onclick="visionScan.showComparison('antireflexo')">
                        Anti-Reflexo
                    </button>
                    <button class="comp-tab" onclick="visionScan.showComparison('filtroazul')">
                        Filtro Azul
                    </button>
                    <button class="comp-tab" onclick="visionScan.showComparison('digital')">
                        Digital
                    </button>
                </div>
                
                <div class="comparison-view" id="comparisonView">
                    <div class="lens-demo">
                        <div class="lens-side">
                            <h4>Lente Convencional</h4>
                            <div class="lens-visual conventional">
                                <div class="reflection strong"></div>
                                <div class="clarity low"></div>
                            </div>
                            <div class="lens-features">
                                <div class="feature-item negative">Reflexos visíveis</div>
                                <div class="feature-item negative">Menor clareza</div>
                            </div>
                        </div>
                        
                        <div class="vs-divider">VS</div>
                        
                        <div class="lens-side">
                            <h4>Lente Anti-Reflexo</h4>
                            <div class="lens-visual premium">
                                <div class="reflection minimal"></div>
                                <div class="clarity high"></div>
                            </div>
                            <div class="lens-features">
                                <div class="feature-item positive">99% menos reflexos</div>
                                <div class="feature-item positive">Clareza superior</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="demo-controls">
                <button class="demo-action-btn" onclick="visionScan.animateComparison()">
                    <i class="fas fa-play"></i>
                    Ver Animação
                </button>
            </div>
        `;
    }

    createReportDemo() {
        return `
            <div class="demo-header">
                <div class="demo-title">
                    <i class="fas fa-file-alt"></i>
                    <span>Relatório Profissional</span>
                </div>
                <div class="demo-status">Gerando relatório...</div>
            </div>
            
            <div class="report-preview">
                <div class="report-header">
                    <div class="report-logo">
                        <i class="fas fa-eye"></i>
                        <span>Vision-Scan</span>
                    </div>
                    <div class="report-date">${new Date().toLocaleDateString('pt-BR')}</div>
                </div>
                
                <div class="report-content">
                    <div class="client-info">
                        <h3>Dados do Cliente</h3>
                        <div class="info-grid">
                            <div class="info-item">
                                <span class="label">Nome:</span>
                                <span class="value">Maria Silva</span>
                            </div>
                            <div class="info-item">
                                <span class="label">Idade:</span>
                                <span class="value">35 anos</span>
                            </div>
                            <div class="info-item">
                                <span class="label">Data:</span>
                                <span class="value">${new Date().toLocaleDateString('pt-BR')}</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="measurements-section">
                        <h3>Medições Realizadas</h3>
                        <div class="measurements-grid">
                            <div class="measurement-card">
                                <div class="measurement-icon">
                                    <i class="fas fa-ruler"></i>
                                </div>
                                <div class="measurement-data">
                                    <span class="measurement-label">DNP</span>
                                    <span class="measurement-value">64.5mm</span>
                                </div>
                            </div>
                            <div class="measurement-card">
                                <div class="measurement-icon">
                                    <i class="fas fa-arrows-alt-v"></i>
                                </div>
                                <div class="measurement-data">
                                    <span class="measurement-label">Altura</span>
                                    <span class="measurement-value">28.2mm</span>
                                </div>
                            </div>
                            <div class="measurement-card">
                                <div class="measurement-icon">
                                    <i class="fas fa-eye"></i>
                                </div>
                                <div class="measurement-data">
                                    <span class="measurement-label">Pupila</span>
                                    <span class="measurement-value">3.2mm</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="recommendations-section">
                        <h3>Recomendações</h3>
                        <div class="rec-list">
                            <div class="rec-item">
                                <i class="fas fa-check-circle"></i>
                                <span>Armação retangular ou quadrada</span>
                            </div>
                            <div class="rec-item">
                                <i class="fas fa-check-circle"></i>
                                <span>Lentes anti-reflexo premium</span>
                            </div>
                            <div class="rec-item">
                                <i class="fas fa-check-circle"></i>
                                <span>Filtro de luz azul recomendado</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="report-footer">
                    <div class="signature">
                        <p>Relatório gerado pelo Vision-Scan</p>
                        <p>Tecnologia Íris Clin</p>
                    </div>
                </div>
            </div>
            
            <div class="demo-controls">
                <button class="demo-action-btn" onclick="visionScan.downloadReport()">
                    <i class="fas fa-download"></i>
                    Baixar PDF
                </button>
                <button class="demo-action-btn secondary" onclick="visionScan.shareReport()">
                    <i class="fas fa-share"></i>
                    Compartilhar
                </button>
            </div>
        `;
    }

    initDemoInteractions() {
        // Add specific interactions based on current demo
        switch(this.currentDemo) {
            case 'measurement':
                this.initMeasurementDemo();
                break;
            case 'analysis':
                this.initAnalysisDemo();
                break;
            case 'comparison':
                this.initComparisonDemo();
                break;
            case 'report':
                this.initReportDemo();
                break;
        }
    }

    initMeasurementDemo() {
        // Animate measurement line
        const measurementLine = document.querySelector('.measurement-line');
        if (measurementLine) {
            setInterval(() => {
                const randomDNP = (Math.random() * 10 + 60).toFixed(1);
                const valueElement = measurementLine.querySelector('.measurement-value');
                if (valueElement) {
                    valueElement.textContent = `${randomDNP}mm`;
                }
                
                const dnpValueElement = document.getElementById('dnpValue');
                if (dnpValueElement) {
                    dnpValueElement.textContent = `${randomDNP}mm`;
                }
            }, 3000);
        }
    }

    initAnalysisDemo() {
        // Animate mesh points
        const meshPoints = document.querySelectorAll('.mesh-point');
        meshPoints.forEach((point, index) => {
            setTimeout(() => {
                point.style.animation = 'pointPulse 2s ease-in-out infinite';
            }, index * 200);
        });
    }

    initComparisonDemo() {
        // Initialize comparison animations
        this.animateComparison();
    }

    initReportDemo() {
        // Animate report generation
        setTimeout(() => {
            const status = document.querySelector('.demo-status');
            if (status) {
                status.textContent = 'Relatório concluído';
                status.style.color = '#4CAF50';
            }
        }, 2000);
    }

    startScan() {
        if (this.isScanning) return;
        
        this.isScanning = true;
        const scanBtn = document.querySelector('.scan-btn');
        const status = document.querySelector('.demo-status');
        
        if (scanBtn) {
            scanBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Escaneando...';
            scanBtn.disabled = true;
        }
        
        if (status) {
            status.textContent = 'Escaneando...';
            status.style.color = '#FF9800';
        }

        // Simulate scanning process
        setTimeout(() => {
            this.completeScan();
        }, 3000);
    }

    completeScan() {
        this.isScanning = false;
        const scanBtn = document.querySelector('.scan-btn');
        const status = document.querySelector('.demo-status');
        
        // Generate random measurements
        this.measurements = {
            dnp: (Math.random() * 10 + 60).toFixed(1),
            height: (Math.random() * 5 + 25).toFixed(1),
            angle: (Math.random() * 10 + 5).toFixed(1),
            pupilDiameter: (Math.random() * 2 + 2).toFixed(1)
        };

        // Update UI
        if (scanBtn) {
            scanBtn.innerHTML = '<i class="fas fa-check"></i> Concluído';
            scanBtn.style.background = '#4CAF50';
        }
        
        if (status) {
            status.textContent = 'Medição concluída';
            status.style.color = '#4CAF50';
        }

        // Update measurement values
        const dnpValue = document.getElementById('dnpValue');
        const heightValue = document.getElementById('heightValue');
        
        if (dnpValue) dnpValue.textContent = `${this.measurements.dnp}mm`;
        if (heightValue) heightValue.textContent = `${this.measurements.height}mm`;

        // Reset button after 2 seconds
        setTimeout(() => {
            if (scanBtn) {
                scanBtn.innerHTML = '<i class="fas fa-camera"></i> Nova Medição';
                scanBtn.style.background = '';
                scanBtn.disabled = false;
            }
            if (status) {
                status.textContent = 'Pronto para escanear';
                status.style.color = '';
            }
        }, 2000);
    }

    showComparison(type) {
        // Update active tab
        document.querySelectorAll('.comp-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        event.target.classList.add('active');

        const comparisonView = document.getElementById('comparisonView');
        if (!comparisonView) return;

        const comparisons = {
            antireflexo: this.createAntiReflexComparison(),
            filtroazul: this.createBlueFilterComparison(),
            digital: this.createDigitalComparison()
        };

        comparisonView.innerHTML = comparisons[type] || comparisons.antireflexo;
    }

    createAntiReflexComparison() {
        return `
            <div class="lens-demo">
                <div class="lens-side">
                    <h4>Lente Convencional</h4>
                    <div class="lens-visual conventional">
                        <div class="reflection strong"></div>
                        <div class="clarity low"></div>
                    </div>
                    <div class="lens-features">
                        <div class="feature-item negative">Reflexos visíveis</div>
                        <div class="feature-item negative">Menor clareza</div>
                        <div class="feature-item negative">Fadiga visual</div>
                    </div>
                </div>
                
                <div class="vs-divider">VS</div>
                
                <div class="lens-side">
                    <h4>Lente Anti-Reflexo</h4>
                    <div class="lens-visual premium">
                        <div class="reflection minimal"></div>
                        <div class="clarity high"></div>
                    </div>
                    <div class="lens-features">
                        <div class="feature-item positive">99% menos reflexos</div>
                        <div class="feature-item positive">Clareza superior</div>
                        <div class="feature-item positive">Conforto visual</div>
                    </div>
                </div>
            </div>
        `;
    }

    createBlueFilterComparison() {
        return `
            <div class="lens-demo">
                <div class="lens-side">
                    <h4>Lente Normal</h4>
                    <div class="lens-visual normal">
                        <div class="blue-light strong"></div>
                        <div class="eye-strain high"></div>
                    </div>
                    <div class="lens-features">
                        <div class="feature-item negative">Luz azul nociva</div>
                        <div class="feature-item negative">Fadiga digital</div>
                        <div class="feature-item negative">Sono prejudicado</div>
                    </div>
                </div>
                
                <div class="vs-divider">VS</div>
                
                <div class="lens-side">
                    <h4>Filtro Azul</h4>
                    <div class="lens-visual blue-filter">
                        <div class="blue-light filtered"></div>
                        <div class="eye-strain low"></div>
                    </div>
                    <div class="lens-features">
                        <div class="feature-item positive">Bloqueia luz azul</div>
                        <div class="feature-item positive">Reduz fadiga</div>
                        <div class="feature-item positive">Melhora o sono</div>
                    </div>
                </div>
            </div>
        `;
    }

    createDigitalComparison() {
        return `
            <div class="lens-demo">
                <div class="lens-side">
                    <h4>Lente Convencional</h4>
                    <div class="lens-visual conventional">
                        <div class="field-view limited"></div>
                        <div class="aberration high"></div>
                    </div>
                    <div class="lens-features">
                        <div class="feature-item negative">Campo visual limitado</div>
                        <div class="feature-item negative">Aberrações cromáticas</div>
                        <div class="feature-item negative">Distorções periféricas</div>
                    </div>
                </div>
                
                <div class="vs-divider">VS</div>
                
                <div class="lens-side">
                    <h4>Lente Digital</h4>
                    <div class="lens-visual digital">
                        <div class="field-view expanded"></div>
                        <div class="aberration minimal"></div>
                    </div>
                    <div class="lens-features">
                        <div class="feature-item positive">Campo visual amplo</div>
                        <div class="feature-item positive">Sem aberrações</div>
                        <div class="feature-item positive">Visão nítida total</div>
                    </div>
                </div>
            </div>
        `;
    }

    animateComparison() {
        const lensVisuals = document.querySelectorAll('.lens-visual');
        lensVisuals.forEach((visual, index) => {
            setTimeout(() => {
                visual.style.transform = 'scale(1.05)';
                setTimeout(() => {
                    visual.style.transform = 'scale(1)';
                }, 500);
            }, index * 300);
        });
    }

    downloadReport() {
        // Simulate PDF download
        const link = document.createElement('a');
        link.href = '#';
        link.download = 'relatorio-vision-scan.pdf';
        
        // Show success message
        this.showNotification('Relatório baixado com sucesso!', 'success');
    }

    shareReport() {
        // Simulate sharing
        if (navigator.share) {
            navigator.share({
                title: 'Relatório Vision-Scan',
                text: 'Confira o relatório de medições ópticas',
                url: window.location.href
            });
        } else {
            // Fallback for browsers without Web Share API
            this.showNotification('Link copiado para a área de transferência!', 'info');
        }
    }

    handlePricingClick(button) {
        const card = button.closest('.pricing-card');
        const planName = card.querySelector('h3').textContent;
        
        if (button.textContent.includes('Grátis')) {
            this.startTrial();
        } else {
            this.selectPlan(planName);
        }
    }

    startTrial() {
        this.showNotification('Redirecionando para cadastro gratuito...', 'info');
        setTimeout(() => {
            // Simulate redirect to trial signup
            console.log('Redirecting to trial signup...');
        }, 1500);
    }

    selectPlan(planName) {
        this.showNotification(`Plano ${planName} selecionado! Redirecionando...`, 'success');
        setTimeout(() => {
            // Simulate redirect to payment
            console.log(`Redirecting to payment for ${planName}...`);
        }, 1500);
    }

    handleContactSubmit(event) {
        const formData = new FormData(event.target);
        const data = Object.fromEntries(formData);
        
        // Simulate form submission
        this.showNotification('Mensagem enviada com sucesso! Entraremos em contato em breve.', 'success');
        event.target.reset();
    }

    handleLogin(event) {
        const formData = new FormData(event.target);
        const email = formData.get('email');
        const password = formData.get('password');
        
        // Simulate login
        if (email && password) {
            this.showNotification('Login realizado com sucesso!', 'success');
            this.closeLogin();
            setTimeout(() => {
                // Simulate redirect to dashboard
                console.log('Redirecting to dashboard...');
            }, 1500);
        } else {
            this.showNotification('Por favor, preencha todos os campos.', 'error');
        }
    }

    openLogin() {
        const modal = document.getElementById('loginModal');
        if (modal) {
            modal.style.display = 'block';
        }
    }

    closeLogin() {
        const modal = document.getElementById('loginModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-${this.getNotificationIcon(type)}"></i>
                <span>${message}</span>
            </div>
        `;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${this.getNotificationColor(type)};
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            z-index: 3000;
            animation: slideInRight 0.3s ease-out;
            max-width: 400px;
        `;
        
        document.body.appendChild(notification);
        
        // Remove after 4 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 4000);
    }

    getNotificationIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        return icons[type] || 'info-circle';
    }

    getNotificationColor(type) {
        const colors = {
            success: '#4CAF50',
            error: '#f44336',
            warning: '#FF9800',
            info: '#2196F3'
        };
        return colors[type] || '#2196F3';
    }

    startAnimations() {
        // Add CSS animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            
            @keyframes slideOutRight {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
            
            .notification-content {
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }
            
            /* Demo specific styles */
            .demo-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 1.5rem;
                padding-bottom: 1rem;
                border-bottom: 1px solid #e0e0e0;
            }
            
            .demo-title {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                font-weight: 600;
                color: #333;
            }
            
            .demo-status {
                font-size: 0.9rem;
                color: #666;
                padding: 0.25rem 0.75rem;
                background: #f5f5f5;
                border-radius: 15px;
            }
            
            .demo-camera {
                margin-bottom: 1.5rem;
            }
            
            .camera-view {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border-radius: 12px;
                padding: 2rem;
                position: relative;
                min-height: 200px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .face-outline {
                width: 150px;
                height: 100px;
                border: 2px solid rgba(255,255,255,0.5);
                border-radius: 50%;
                position: relative;
                display: flex;
                align-items: center;
                justify-content: space-around;
                padding: 0 20px;
            }
            
            .eye {
                width: 30px;
                height: 20px;
                background: rgba(255,255,255,0.8);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .pupil {
                width: 12px;
                height: 12px;
                background: #333;
                border-radius: 50%;
                animation: pupilPulse 2s ease-in-out infinite;
            }
            
            .measurement-line {
                position: absolute;
                top: 50%;
                left: 0;
                right: 0;
                height: 2px;
                background: #4CAF50;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .measurement-value {
                background: #4CAF50;
                color: white;
                padding: 0.25rem 0.5rem;
                border-radius: 4px;
                font-size: 0.8rem;
                font-weight: 600;
            }
            
            .scan-overlay {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                pointer-events: none;
            }
            
            .scan-grid {
                width: 100%;
                height: 100%;
                background-image: 
                    linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                    linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px);
                background-size: 20px 20px;
                animation: gridMove 4s linear infinite;
            }
            
            @keyframes gridMove {
                0% { transform: translate(0, 0); }
                100% { transform: translate(20px, 20px); }
            }
            
            .demo-controls {
                text-align: center;
                margin-bottom: 1.5rem;
            }
            
            .scan-btn, .demo-action-btn {
                background: linear-gradient(135deg, #2196F3, #4CAF50);
                color: white;
                border: none;
                padding: 0.75rem 1.5rem;
                border-radius: 25px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                display: inline-flex;
                align-items: center;
                gap: 0.5rem;
                margin: 0 0.5rem;
            }
            
            .scan-btn:hover, .demo-action-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 25px rgba(33, 150, 243, 0.3);
            }
            
            .demo-action-btn.secondary {
                background: transparent;
                color: #2196F3;
                border: 2px solid #2196F3;
            }
            
            .demo-results {
                background: #f8f9fa;
                border-radius: 8px;
                padding: 1rem;
            }
            
            .result-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0.5rem 0;
                border-bottom: 1px solid #e0e0e0;
            }
            
            .result-item:last-child {
                border-bottom: none;
            }
            
            .result-item .label {
                font-weight: 500;
                color: #666;
            }
            
            .result-item .value {
                font-weight: 600;
                color: #333;
            }
            
            .result-item .value.success {
                color: #4CAF50;
            }
            
            /* Analysis Demo Styles */
            .face-analysis {
                position: relative;
                width: 120px;
                height: 120px;
            }
            
            .face-mesh {
                position: relative;
                width: 100%;
                height: 100%;
            }
            
            .mesh-point {
                position: absolute;
                width: 8px;
                height: 8px;
                background: #4CAF50;
                border-radius: 50%;
                box-shadow: 0 0 10px rgba(76, 175, 80, 0.8);
            }
            
            .face-outline-analysis {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                border: 2px solid rgba(255,255,255,0.6);
                border-radius: 50%;
                animation: outlinePulse 3s ease-in-out infinite;
            }
            
            @keyframes outlinePulse {
                0%, 100% { transform: scale(1); opacity: 0.6; }
                50% { transform: scale(1.1); opacity: 1; }
            }
            
            .analysis-result {
                margin-bottom: 1rem;
            }
            
            .result-category {
                display: flex;
                justify-content: space-between;
                padding: 0.5rem 0;
                border-bottom: 1px solid #e0e0e0;
            }
            
            .category-label {
                font-weight: 500;
                color: #666;
            }
            
            .category-value {
                font-weight: 600;
                color: #2196F3;
            }
            
            .recommendations h4 {
                margin-bottom: 0.5rem;
                color: #333;
            }
            
            .rec-item {
                padding: 0.25rem 0;
                color: #4CAF50;
                font-size: 0.9rem;
            }
            
            /* Comparison Demo Styles */
            .comparison-container {
                width: 100%;
            }
            
            .comparison-tabs {
                display: flex;
                margin-bottom: 1rem;
                background: #f5f5f5;
                border-radius: 8px;
                padding: 4px;
            }
            
            .comp-tab {
                flex: 1;
                padding: 0.5rem 1rem;
                background: transparent;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                transition: all 0.3s ease;
                font-weight: 500;
            }
            
            .comp-tab.active {
                background: white;
                color: #2196F3;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            
            .lens-demo {
                display: grid;
                grid-template-columns: 1fr auto 1fr;
                gap: 1rem;
                align-items: center;
            }
            
            .lens-side {
                text-align: center;
            }
            
            .lens-side h4 {
                margin-bottom: 1rem;
                color: #333;
                font-size: 1rem;
            }
            
            .lens-visual {
                width: 80px;
                height: 50px;
                border-radius: 25px;
                margin: 0 auto 1rem;
                position: relative;
                transition: all 0.3s ease;
            }
            
            .lens-visual.conventional {
                background: linear-gradient(135deg, #ccc, #999);
            }
            
            .lens-visual.premium {
                background: linear-gradient(135deg, #2196F3, #4CAF50);
                box-shadow: 0 0 20px rgba(33, 150, 243, 0.4);
            }
            
            .lens-visual.normal {
                background: linear-gradient(135deg, #ffeb3b, #ffc107);
            }
            
            .lens-visual.blue-filter {
                background: linear-gradient(135deg, #3f51b5, #2196f3);
            }
            
            .lens-visual.digital {
                background: linear-gradient(135deg, #9c27b0, #e91e63);
            }
            
            .vs-divider {
                font-weight: 700;
                color: #666;
                font-size: 1.2rem;
            }
            
            .lens-features {
                display: flex;
                flex-direction: column;
                gap: 0.25rem;
            }
            
            .feature-item {
                font-size: 0.8rem;
                padding: 0.25rem 0.5rem;
                border-radius: 4px;
            }
            
            .feature-item.positive {
                background: rgba(76, 175, 80, 0.1);
                color: #4CAF50;
            }
            
            .feature-item.negative {
                background: rgba(244, 67, 54, 0.1);
                color: #f44336;
            }
            
            /* Report Demo Styles */
            .report-preview {
                background: white;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                overflow: hidden;
                margin-bottom: 1rem;
                max-height: 400px;
                overflow-y: auto;
            }
            
            .report-header {
                background: linear-gradient(135deg, #2196F3, #4CAF50);
                color: white;
                padding: 1rem;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .report-logo {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                font-weight: 600;
            }
            
            .report-content {
                padding: 1rem;
            }
            
            .client-info, .measurements-section, .recommendations-section {
                margin-bottom: 1.5rem;
            }
            
            .client-info h3, .measurements-section h3, .recommendations-section h3 {
                color: #333;
                margin-bottom: 0.75rem;
                font-size: 1rem;
                border-bottom: 2px solid #2196F3;
                padding-bottom: 0.25rem;
            }
            
            .info-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
                gap: 0.5rem;
            }
            
            .info-item {
                display: flex;
                flex-direction: column;
                gap: 0.25rem;
            }
            
            .info-item .label {
                font-size: 0.8rem;
                color: #666;
                font-weight: 500;
            }
            
            .info-item .value {
                font-weight: 600;
                color: #333;
            }
            
            .measurements-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
                gap: 0.75rem;
            }
            
            .measurement-card {
                background: #f8f9fa;
                border-radius: 8px;
                padding: 0.75rem;
                text-align: center;
                border: 1px solid #e0e0e0;
            }
            
            .measurement-icon {
                color: #2196F3;
                font-size: 1.2rem;
                margin-bottom: 0.5rem;
            }
            
            .measurement-data {
                display: flex;
                flex-direction: column;
                gap: 0.25rem;
            }
            
            .measurement-label {
                font-size: 0.8rem;
                color: #666;
                font-weight: 500;
            }
            
            .measurement-value {
                font-weight: 700;
                color: #333;
                font-size: 1.1rem;
            }
            
            .rec-list {
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .rec-list .rec-item {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                color: #4CAF50;
                font-size: 0.9rem;
            }
            
            .report-footer {
                background: #f8f9fa;
                padding: 1rem;
                text-align: center;
                border-top: 1px solid #e0e0e0;
            }
            
            .signature p {
                margin: 0;
                color: #666;
                font-size: 0.8rem;
            }
        `;
        document.head.appendChild(style);
    }
}

// Global functions for onclick handlers
function openLogin() {
    visionScan.openLogin();
}

function closeLogin() {
    visionScan.closeLogin();
}

function startTrial() {
    visionScan.startTrial();
}

function startDemo() {
    document.getElementById('demo').scrollIntoView({ behavior: 'smooth' });
}

function showDemo(type) {
    visionScan.showDemo(type);
}

// Initialize Vision-Scan when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.visionScan = new VisionScan();
    
    // Close modal when clicking outside
    window.addEventListener('click', (event) => {
        const modal = document.getElementById('loginModal');
        if (event.target === modal) {
            visionScan.closeLogin();
        }
    });
    
    // Handle scroll for header background
    window.addEventListener('scroll', () => {
        const header = document.querySelector('.header');
        if (window.scrollY > 100) {
            header.style.background = 'rgba(255, 255, 255, 0.98)';
        } else {
            header.style.background = 'rgba(255, 255, 255, 0.95)';
        }
    });
});

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VisionScan;
}

