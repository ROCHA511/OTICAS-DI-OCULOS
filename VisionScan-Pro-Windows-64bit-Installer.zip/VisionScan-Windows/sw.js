// Vision-Scan Beta - Service Worker
const CACHE_NAME = 'vision-scan-beta-v1.0';
const urlsToCache = [
  '/beta.html',
  '/styles.css',
  '/script.js',
  '/manifest.json',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap'
];

// Install event
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Vision-Scan cache opened');
        return cache.addAll(urlsToCache);
      })
  );
});

// Fetch event
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Return cached version or fetch from network
        if (response) {
          return response;
        }
        return fetch(event.request);
      }
    )
  );
});

// Activate event
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Background sync for offline measurements
self.addEventListener('sync', (event) => {
  if (event.tag === 'background-sync') {
    event.waitUntil(syncMeasurements());
  }
});

async function syncMeasurements() {
  try {
    // Get offline measurements from IndexedDB
    const measurements = await getOfflineMeasurements();
    
    // Sync with server when online
    for (const measurement of measurements) {
      await syncMeasurement(measurement);
    }
    
    console.log('Measurements synced successfully');
  } catch (error) {
    console.error('Sync failed:', error);
  }
}

// Push notifications for updates
self.addEventListener('push', (event) => {
  const options = {
    body: event.data ? event.data.text() : 'Nova atualização disponível!',
    icon: '/icon-192.png',
    badge: '/badge-72.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: 'Abrir App',
        icon: '/icon-explore.png'
      },
      {
        action: 'close',
        title: 'Fechar',
        icon: '/icon-close.png'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('Vision-Scan Beta', options)
  );
});

// Handle notification clicks
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'explore') {
    event.waitUntil(
      clients.openWindow('/beta.html')
    );
  }
});

// Helper functions for IndexedDB
async function getOfflineMeasurements() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('VisionScanDB', 1);
    
    request.onsuccess = (event) => {
      const db = event.target.result;
      const transaction = db.transaction(['measurements'], 'readonly');
      const store = transaction.objectStore('measurements');
      const getAllRequest = store.getAll();
      
      getAllRequest.onsuccess = () => {
        resolve(getAllRequest.result);
      };
    };
    
    request.onerror = () => {
      reject(request.error);
    };
  });
}

async function syncMeasurement(measurement) {
  try {
    const response = await fetch('/api/sync-measurement', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(measurement)
    });
    
    if (response.ok) {
      // Remove from local storage after successful sync
      await removeLocalMeasurement(measurement.id);
    }
  } catch (error) {
    console.error('Failed to sync measurement:', error);
  }
}

async function removeLocalMeasurement(id) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('VisionScanDB', 1);
    
    request.onsuccess = (event) => {
      const db = event.target.result;
      const transaction = db.transaction(['measurements'], 'readwrite');
      const store = transaction.objectStore('measurements');
      const deleteRequest = store.delete(id);
      
      deleteRequest.onsuccess = () => {
        resolve();
      };
    };
    
    request.onerror = () => {
      reject(request.error);
    };
  });
}

