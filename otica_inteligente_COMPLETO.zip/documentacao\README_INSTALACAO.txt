INSTRUÇÕES DE INSTALAÇÃO RÁPIDA:

1. Instale Python 3.10+, Node.js 18+ e PostgreSQL
2. Crie o banco com o script em /database/dump.sql
3. Backend:
   cd backend
   pip install -r requirements.txt
   uvicorn main:app --reload
4. Frontend:
   cd frontend
   npm install
   npm run dev
5. Acesse via navegador e instale como app no iPhone usando Safari (Compartilhar > Adicionar à Tela de Início)

Acesso por senha do Diretor: obrigatório para ajustes e aprovações finais.
