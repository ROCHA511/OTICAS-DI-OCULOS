1. Rodar backend
2. Acessar frontend
3. Instalar no iPhone via Safari